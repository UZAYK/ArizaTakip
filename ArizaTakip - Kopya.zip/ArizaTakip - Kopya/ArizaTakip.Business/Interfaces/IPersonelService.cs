﻿using ArizaTakip.Entites.Concrete;
using ArizaTakip.Entities.Concrete;
using System;
using System.Collections.Generic;
using System.Text;

namespace ArizaTakip.Business.Interfaces
{
    public interface IPersonelService : IGenericService<Personel>
    {
    }
}
