﻿using ArizaTakip.Entites.Concrete;
using System;
using System.Collections.Generic;
using System.Text;

namespace ArizaTakip.Business.Interfaces
{
   public interface ICihazOzellikService : IGenericService<CihazOzellik>
    {
    }
}
