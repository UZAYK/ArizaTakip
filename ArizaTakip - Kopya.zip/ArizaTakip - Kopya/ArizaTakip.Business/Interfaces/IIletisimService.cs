﻿using ArizaTakip.Entities.Concrete;
using System;
using System.Collections.Generic;
using System.Text;

namespace ArizaTakip.Business.Interfaces
{
    public interface IIletisimService : IGenericService<Iletisim>
    {
    }
}
