﻿using ArizaTakip.Entites.Concrete;

namespace ArizaTakip.Business.Interfaces
{
    public interface ICihazService : IGenericService<Cihaz>
    {
    }
}
