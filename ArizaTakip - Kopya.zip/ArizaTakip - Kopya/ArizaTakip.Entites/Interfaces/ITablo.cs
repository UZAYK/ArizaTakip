﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ArizaTakip.Entites.Interfaces
{
    public interface ITablo
    {
     // signalr   
     // ticket 
    }
}
