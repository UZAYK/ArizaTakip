﻿using System;
using System.Collections.Generic;
using System.Text;

using ArizaTakip.Entites.Concrete;
namespace ArizaTakip.DataAccess.Interfaces

{
    public interface ICihazOzellikDal : IGenericDal<CihazOzellik>
    {
        //void Kaydet ( CihazOzellik tablo);
        //void Sil(CihazOzellik tablo);
        //void Guncelle(CihazOzellik tablo);
        //CihazOzellik GetirIdile(int id);
        //List<CihazOzellik> GetirHepsi();
    }
}
