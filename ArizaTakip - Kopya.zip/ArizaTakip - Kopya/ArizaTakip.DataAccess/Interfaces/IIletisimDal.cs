﻿using ArizaTakip.Entities.Concrete;
using System;
using System.Collections.Generic;
using System.Text;

namespace ArizaTakip.DataAccess.Interfaces
{
    public interface IIletisimDal : IGenericDal<Iletisim>
    {

    }
}
