﻿using ArizaTakip.DataAccess.Interfaces;
using ArizaTakip.Entites.Concrete;
using System;
using System.Collections.Generic;
using System.Text;
using ArizaTakip.DataAccess.Concrete.EntitiyFrameworkCore.Contexts;

namespace ArizaTakip.DataAccess.Concrete.EntitiyFrameworkCore.Repositories
{
    public class EfCihazOzellikRepository : EfGenericRepository<CihazOzellik>, ICihazOzellikDal 
    {
      
    }
}
