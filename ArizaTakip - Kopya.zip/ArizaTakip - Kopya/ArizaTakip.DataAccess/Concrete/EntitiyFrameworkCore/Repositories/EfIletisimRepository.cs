﻿using ArizaTakip.DataAccess.Interfaces;
using ArizaTakip.Entities.Concrete;
using System;
using System.Collections.Generic;
using System.Text;

namespace ArizaTakip.DataAccess.Concrete.EntitiyFrameworkCore.Repositories
{
    public class EfIletisimRepository : EfGenericRepository<Iletisim>, IIletisimDal
    {

    }
}
